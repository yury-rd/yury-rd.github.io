REGULARIZED REGRESSION — EDITABLE LATEX / OVERLEAF PROJECT

Modern efficient numerical approaches to regularized regression problems in
application to traffic demands matrix calculation from link loads

This project was newly reconstructed from the Microsoft Word-generated PDF
arXiv:1508.00858v9. No editable DOC/DOCX or original author LaTeX source was
obtained; this is a transcription into LaTeX, not the original author source.
Source: https://arxiv.org/abs/1508.00858v9 (revision 17 April 2016).
The inventory retains the publication year 2015 from the Scholar record.

OVERLEAF
Create a new project by uploading regularized-regression-overleaf.zip.
Set the main document to main.tex and the compiler to pdfLaTeX. The project
uses standard TeX Live packages and needs no external assets or shell escape.

LOCAL BUILD
Run: latexmk -pdf main.tex

CONTENT AND CHECKS
The rebuilt PDF has 13 pages; the Word-generated source has 16 pages.
Text, equations, the complexity comparison table and all 27 bibliography
entries are editable. All eight footnotes are retained. There are no embedded
page images. Compilation and all rendered pages were checked.

All eight authors and their original affiliations are retained because this
paper predates the requested 2023 affiliation cutoff. The funding paragraph
was omitted as requested; nonfinancial acknowledgments remain. Scientific
wording and notation were transcribed, including pre-existing inconsistencies.
This conversion does not constitute a mathematical revision or proof audit.

The full publication collection preserves the original PDF in originals/.
Its website/ directory contains the updated PDF under:
2015_regularized-regression_Anikin-et-al__latex.pdf

provenance.json records the source and checksums; validation.json records
the compilation, text and layout checks.
